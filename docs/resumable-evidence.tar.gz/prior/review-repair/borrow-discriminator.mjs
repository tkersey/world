import {execFileSync} from 'node:child_process';
import {readFileSync,writeFileSync,openSync,closeSync} from 'node:fs';
import {createHash} from 'node:crypto';
const r='/Users/tk/workspace/tk/world-evidence-01a0fc7f',c='/Users/tk/workspace/tk/world-change-proportional-01a0fc7f',b='/Users/tk/workspace/tk/world-baseline-01a0fc7f',e=c+'/src/embedding/index.mjs',bk=b+'/zig-out/world-kernel.wasm',ak=r+'/borrow-build/runtime/world-kernel.wasm',median=a=>[...a].sort((a,b)=>a-b)[Math.floor(a.length/2)];
const report={status:'running',kernels:{before:createHash('sha256').update(readFileSync(bk)).digest('hex'),after:createHash('sha256').update(readFileSync(ak)).digest('hex')},cells:[]};
for(const mode of ['H','Q']){
 const windows=[];
 for(let w=0;w<5;w++){
  const results={};for(const arm of w%2?['after','before']:['before','after'])results[arm]=JSON.parse(execFileSync(process.execPath,[c+'/test/current/retained_history_wasm.mjs','sample',e,arm==='before'?bk:ak,r+'/fixtures/'+mode+'.bpi3',mode,'1024',r+'/fixtures/'+mode+'-1024.json'],{encoding:'utf8',timeout:180000}));
  windows.push({...results,ratio:median(results.after.samples.map(x=>x.totalNs))/median(results.before.samples.map(x=>x.totalNs))});
 }
 const ratio=median(windows.map(x=>x.ratio));report.cells.push({mode,ratio,windows});writeFileSync(r+'/borrow-primary.json',JSON.stringify(report,null,2));console.log(mode,ratio,windows.map(x=>x.ratio));
}
report.status='complete';writeFileSync(r+'/borrow-primary.json',JSON.stringify(report,null,2));
for(const[name,script,args]of[
 ['scalar-native','scalar_batch_timing.mjs',[r+'/baseline-native/bin/scalar_batch_bench',r+'/borrow-native/bin/scalar_batch_bench',r+'/borrow-scalar-native.json']],
 ['scalar-wasm','scalar_batch_wasm_timing.mjs',[e,bk,ak,r+'/scalar-corpus',r+'/borrow-scalar-wasm.json']]
]){const fd=openSync(r+'/borrow-'+name+'.log','w');try{execFileSync(process.execPath,[c+'/test/current/'+script,...args],{cwd:c,stdio:['ignore',fd,fd],timeout:900000});}finally{closeSync(fd);}const rows=JSON.parse(readFileSync(r+'/borrow-'+name+'.json'));console.log(name,JSON.stringify(rows.cells?.filter(x=>x.confirmedSlowdown)));}
