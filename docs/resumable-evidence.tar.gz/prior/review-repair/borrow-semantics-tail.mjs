import{readFileSync,writeFileSync,openSync,closeSync}from'node:fs';import{execFileSync}from'node:child_process';import{createHash}from'node:crypto';import assert from'node:assert/strict';
const r='/Users/tk/workspace/tk/world-evidence-01a0fc7f',c='/Users/tk/workspace/tk/world-change-proportional-01a0fc7f',b='/Users/tk/workspace/tk/world-baseline-01a0fc7f',e=c+'/src/embedding/index.mjs',bk=b+'/zig-out/world-kernel.wasm',ak=r+'/borrow-build/runtime/world-kernel.wasm',bn=r+'/baseline-native/bin',an=r+'/borrow-native/bin',hash=p=>createHash('sha256').update(readFileSync(p)).digest('hex');
const q='/Users/tk/workspace/tk/world-evidence-01a0fc7f/borrow-qualification';
const unusedInitialReport={sourceHead:execFileSync('git',['-C',c,'rev-parse','HEAD'],{encoding:'utf8'}).trim(),kernels:{before:hash(bk),after:hash(ak)},native:{before:hash(bn+'/agent-native'),after:hash(an+'/agent-native')},status:'running',stages:[],structure:{before:[],after:[]},memory:[],complete:[]};
const report=JSON.parse(readFileSync(q+'/final-semantics.json'));
const save=()=>writeFileSync(q+'/final-semantics.json',JSON.stringify(report,null,2));
function stage(name,script,args){console.log('START '+name);const fd=openSync(q+'/final-'+name+'.log','w');try{execFileSync(process.execPath,[c+'/test/current/'+script,...args],{cwd:c,stdio:['ignore',fd,fd],timeout:600000});}finally{closeSync(fd);}report.stages.push(name);save();console.log('PASS '+name);}
stage('scalar-platform','scalar_batch_platform.mjs',[e,bk,ak,bn+'/scalar-fixture',an+'/agent-native',r+'/scalar-corpus',q+'/final-scalar-platform.json']);
stage('scalar-failures','scalar_batch_failures.mjs',[e,bk,ak,bn+'/scalar-fixture',q+'/final-scalar-failures.json']);
stage('frame-platform','frame_reuse_platform.mjs',[e,bk,ak,bn+'/frame-fixture',r+'/frame-corpus',q+'/final-frame-platform.json']);
stage('blob-platform','blob_retention_platform.mjs',[e,bk,ak,an+'/blob-fixture',r+'/blob-corpus',q+'/final-blob-platform.json']);
stage('retained-transfer','retained_history_transfer.mjs',[bk,ak,bn+'/agent-native',an+'/agent-native',r+'/fixtures',q+'/final-retained-transfer.json']);
stage('retained-browser','browser.mjs',[ak,c+'/zig-out/current/bin/current-fixtures',r+'/fixtures',bk]);
for(const after of report.memory.filter(x=>x.arm==='after')){const before=report.memory.find(x=>x.arm==='before'&&x.mode===after.mode&&x.depth===after.depth&&x.profile===after.profile);assert(before);assert(after.peakBytes-before.peakBytes<=Math.max(1024,Math.ceil(before.peakBytes*.01)));}
report.status='complete';save();console.log('FINAL SEMANTICS COMPLETE');
