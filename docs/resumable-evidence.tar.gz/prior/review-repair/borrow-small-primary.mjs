import{execFileSync}from'node:child_process';import{readFileSync,writeFileSync}from'node:fs';
const r='/Users/tk/workspace/tk/world-evidence-01a0fc7f',q=r+'/borrow-qualification',c='/Users/tk/workspace/tk/world-change-proportional-01a0fc7f',b='/Users/tk/workspace/tk/world-baseline-01a0fc7f',e=c+'/src/embedding/index.mjs',bk=b+'/zig-out/world-kernel.wasm',ak=r+'/borrow-build/runtime/world-kernel.wasm',median=a=>[...a].sort((a,b)=>a-b)[Math.floor(a.length/2)],prior=JSON.parse(readFileSync(r+'/borrow-primary.json'));
const report={status:'running',sourceHead:execFileSync('git',['-C',c,'rev-parse','HEAD'],{encoding:'utf8'}).trim(),kernels:prior.kernels,warmups:3,samples:9,windows:5,cells:[]};
for(const mode of['H','Q'])for(const depth of[1,16,64,256,1024]){
 let windows;
 if(depth===1024)windows=prior.cells.find(x=>x.mode===mode).windows;
 else{windows=[];for(let w=0;w<5;w++){const result={};for(const arm of w%2?['after','before']:['before','after'])result[arm]=JSON.parse(execFileSync(process.execPath,[c+'/test/current/retained_history_wasm.mjs','sample',e,arm==='before'?bk:ak,r+'/fixtures/'+mode+'.bpi3',mode,String(depth),r+'/fixtures/'+mode+'-'+depth+'.json'],{encoding:'utf8',timeout:180000}));windows.push({...result,ratio:median(result.after.samples.map(x=>x.totalNs))/median(result.before.samples.map(x=>x.totalNs))});}}
 const ratio=median(windows.map(x=>x.ratio)),confirmedWin=ratio<.95&&windows.filter(x=>x.ratio<.95).length>=4,confirmedSlowdown=ratio>1.05&&windows.filter(x=>x.ratio>1.05).length>=4;
 report.cells.push({mode,depth,primary:depth===1024,ratio,confirmedWin,confirmedSlowdown,beforeNs:median(windows.map(x=>median(x.before.samples.map(x=>x.totalNs)))),afterNs:median(windows.map(x=>median(x.after.samples.map(x=>x.totalNs)))),windows});writeFileSync(q+'/retained-timing.json',JSON.stringify(report,null,2));console.log({mode,depth,ratio,confirmedWin,confirmedSlowdown});
}
report.status='complete';writeFileSync(q+'/retained-timing.json',JSON.stringify(report,null,2));
