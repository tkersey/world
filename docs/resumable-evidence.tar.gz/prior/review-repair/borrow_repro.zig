const std = @import("std");
const data = @import("boundary_data");
const frames_module = @import("frames");
const Frames = frames_module.Frames;
const testing = std.testing;

fn run(comptime kind: enum { pointer, descriptor, read_then_write }) !void {
    var pool: data.analysis_sets.Pool = .{ .allocator = testing.allocator, .limit = 1 };
    defer pool.deinit();
    const functions = [_]data.activation.Function{.{ .entry = 0, .inputs = &.{0}, .layout = .{ .slots = &.{0} }, .result = 0 }};
    var layouts = try frames_module.Layouts.init(testing.allocator, &functions);
    defer layouts.deinit();
    var frames = try Frames.init(testing.allocator, &pool, &layouts);
    defer frames.deinit();
    var original = try frames.create(0);
    try frames.write(&original, 0, natural(10));
    try frames.put(0, original);
    const borrowed: ?*frames_module.Frame = if (kind == .pointer) try frames.getMutable(0) else null;
    var descriptor: frames_module.Frame = if (kind == .descriptor) try frames.get(0) else undefined;
    var backup = if (@hasDecl(Frames, "begin")) blk: {
        try frames.begin(1);
        break :blk {};
    } else try frames.backup();
    if (kind == .read_then_write) descriptor = try frames.get(0);
    const writable = if (kind == .pointer) borrowed.? else &descriptor;
    try frames.write(writable, 0, natural(20));
    writable.position = 7;
    if (@hasDecl(Frames, "begin")) frames.rollback(1) else backup.restore(&frames);
    const restored = try frames.get(0);
    try testing.expectEqual(@as(u64, 10), std.mem.readInt(u64, (try frames.slots.get(restored.view, 0)).body.scalar[0..8], .little));
    try testing.expectEqual(@as(usize, 0), restored.position);
}
fn natural(value: u64) data.graph.Value {
    var scalar = [_]u8{0} ** 8;
    std.mem.writeInt(u64, &scalar, value, .little);
    return .{ .schema = 0, .body = .{ .scalar = scalar } };
}
test "pre-entry mutable pointer" { try run(.pointer); }
test "pre-entry copied descriptor" { try run(.descriptor); }
test "read descriptor followed by sanctioned write" { try run(.read_then_write); }
