const runtime = @import("runtime");
pub export fn resident_bytes() u32 { return @sizeOf(runtime.Resident); }
pub export fn optional_resident_bytes() u32 { return @sizeOf(?runtime.Resident); }
pub export fn session_bytes() u32 { return @sizeOf(runtime.Session); }
pub export fn transaction_bytes() u32 { return @sizeOf(runtime.Session.Transaction); }
pub export fn frames_bytes() u32 { return @sizeOf(@FieldType(runtime.Session, "frames")); }
