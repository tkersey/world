const std = @import("std");
const sizes = @import("representation");
pub fn main(init: std.process.Init) !void {
    var buffer: [1024]u8 = undefined;
    var output = std.Io.File.stdout().writer(init.io, &buffer);
    try std.json.Stringify.value(.{ .resident_bytes = sizes.resident_bytes(), .optional_resident_bytes = sizes.optional_resident_bytes(), .session_bytes = sizes.session_bytes(), .transaction_bytes = sizes.transaction_bytes(), .frames_bytes = sizes.frames_bytes() }, .{}, &output.interface);
    try output.interface.writeByte('\n');
    try output.interface.flush();
}
