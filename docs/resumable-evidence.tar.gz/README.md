# Retained-execution evidence

Runtime source: 424a36ca0921ff408394ba6e8556e89d3f224328. Kernel bytes are controlled local measurement artifacts, not a release or Agent's historical runtime lock. The existing runtime producer supplies the separate final delivery descriptor.

The final directory contains raw paired windows and executed semantic observations. Prior directories retain failed and incomplete attempts with their dispositions; incomplete rows receive no qualification credit. Support contains diagnostic traces, source-import enumeration, the original invalid blob oracle, and selected execution logs.

replay/manifest.json is a derived portable path index for all 662 command/output pairs in 42 scenarios. manifest.original.json preserves the exact report-bound source manifest. All input/output digests are verified during assembly. Original absolute paths in reports remain provenance only; use the portable manifest and corpus directories when replaying elsewhere.

Use the repository's test/current/consumer_replay.mjs and native_consumer_cost.mjs with corpus/economy-corpus and replay/manifest.json. The other test/current probes accept the included corpus files. Rebuild native binaries from the fixed source tuple and the recorded ReleaseSafe commands; original native executables and full build logs remain in the task's retained evidence directory. Machine-specific executable hashes are observations, not cross-platform promises.

The qualification document in the same repository records the fixed inputs, controls, source preservation argument, commands, and acceptance coverage. Engine compilation traces are diagnostic only; no tracing flag was used in acceptance timings.
