const std = @import("std");
const world = @import("world");
const testing = std.testing;
fn prime(a: std.mem.Allocator, prepared: *const world.Prepared) !world.Resident {
    var r = try world.Resident.start(a, prepared, &.{});
    errdefer release(&r);
    var first = try r.drive(a, .none, .{});
    defer first.deinit();
    try testing.expect(first.record == .yielded);
    var cancelled = try r.drive(a, .{ .cancel = .{ .text = "test" } }, .{ .quantum = 0 });
    defer cancelled.deinit();
    return r;
}
fn release(r: *world.Resident) void {
    const checkpoint = r.takeCheckpoint(testing.allocator) catch unreachable;
    testing.allocator.free(checkpoint);
}
test "live owned unwind retains entry state and allocation ownership at every failure" {
    var prepared = try world.Prepared.init(testing.allocator, @embedFile("root-unwind-owned.bpi3"));
    defer prepared.deinit();
    var reference = try prime(testing.allocator, &prepared);
    defer release(&reference);
    var expected = try reference.drive(testing.allocator, .none, .{ .quantum = 1 });
    defer expected.deinit();
    var index: usize = 0;
    while (true) : (index += 1) {
        var failing = testing.FailingAllocator.init(testing.allocator, .{});
        var r = try prime(failing.allocator(), &prepared);
        defer release(&r);
        const entry = try r.checkpoint(testing.allocator);
        defer testing.allocator.free(entry);
        failing.fail_index = failing.alloc_index + index;
        failing.resize_fail_index = failing.resize_index;
        var output = r.drive(failing.allocator(), .none, .{ .quantum = 1 }) catch |err| {
            failing.fail_index = std.math.maxInt(usize);
            failing.resize_fail_index = std.math.maxInt(usize);
            try testing.expectEqual(error.OutOfMemory, err);
            const actual = try r.checkpoint(testing.allocator);
            defer testing.allocator.free(actual);
            try testing.expectEqualSlices(u8, entry, actual);
            var retry = try r.drive(failing.allocator(), .none, .{ .quantum = 1 });
            defer retry.deinit();
            try testing.expectEqualDeep(expected.record, retry.record);
            continue;
        };
        defer output.deinit();
        failing.fail_index = std.math.maxInt(usize);
        failing.resize_fail_index = std.math.maxInt(usize);
        try testing.expectEqualDeep(expected.record, output.record);
        try testing.expect(index > 0);
        break;
    }
}
