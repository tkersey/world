const std = @import("std");
const world = @import("world");
const data = @import("boundary_data");
const testing = std.testing;
test "native Session cancellation invalidates Resident's published reply expectation" {
    var prepared = try world.Prepared.init(testing.allocator, @embedFile("root-binding-unwind.bpi3"));
    defer prepared.deinit();
    var resident = try world.Resident.start(testing.allocator, &prepared, &.{0});
    defer {
        const state = resident.takeCheckpoint(testing.allocator) catch unreachable;
        testing.allocator.free(state);
    }
    var output = try resident.drive(testing.allocator, .none, .{});
    defer output.deinit();
    try testing.expect(output.record == .requested);
    var request = try data.invocation.decode(data.invocation.Request, testing.allocator, output.record.requested.request);
    defer request.deinit();
    try resident.session.?.cancel(.{ .text = "native-session-cancel" });
    var canonical = try resident.session.?.pendingRequest(testing.allocator);
    defer canonical.deinit();
    try testing.expect(!std.mem.eql(u8, &request.value.request_identity, &canonical.request.request_identity));
    const stale = try data.invocation.encodeOwned(data.invocation.Result, testing.allocator, .{ .request_identity = request.value.request_identity, .value = &.{} });
    defer testing.allocator.free(stale);
    if (resident.drive(testing.allocator, .{ .reply = stale }, .{ .quantum = 0 })) |actual| {
        var owned = actual;
        owned.deinit();
        return error.AcceptedStaleBinding;
    } else |err| try testing.expectEqual(error.InvalidResult, err);
}
